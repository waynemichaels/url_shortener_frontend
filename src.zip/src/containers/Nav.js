import React from 'react'

function Nav () {
    return(
      <div className="nav">
        <img className="logo" src="../sample_logo.png" />
      </div>
    )
}

export default Nav;